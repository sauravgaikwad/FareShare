from django.contrib import admin

from .models import Car,Ride

#admin.site.register(Driver)
admin.site.register(Car)
admin.site.register(Ride)
